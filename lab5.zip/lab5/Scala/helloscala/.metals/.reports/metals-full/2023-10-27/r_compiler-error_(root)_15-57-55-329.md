file://<WORKSPACE>/src/main/scala/hello.worksheet.sc
### java.lang.AssertionError: NoDenotation.owner

occurred in the presentation compiler.

action parameters:
offset: 1745
uri: file://<WORKSPACE>/src/main/scala/hello.worksheet.sc
text:
```scala
object worksheet{
  println("Hello, world!")
     
  def reverse4[A, B, C, D](tuple: (A, B, C, D)): (D, C, B, A) = {
    val (a, b, c, d) = tuple
    (d, c, b, a)
  }
  
  val tuple1 = (1, 2, 3, 4)
  val reversed1 = reverse4(tuple1)
  assert (reversed1 == (4, 3, 2, 1));
  
  def sumProd(s: Int, e: Int): (Int, Int) = {
    def loop(n: Int, sum: Int, prod: Int): (Int, Int) = {
      if (n >= e) {
        (sum, prod)
      } else {
        loop(n + 1, sum + n, prod * n)
      }
    }
  
    loop(s, 0, 1)
  }
  
  // Testy
  val (sum1, prod1) = sumProd(2, 6)
  assert(sum1 == 2 + 3 + 4 + 5)
  assert(prod1 == 2 * 3 * 4 * 5)
  
  val (sum2, prod2) = sumProd(1, 5)
  assert(sum2 == 1 + 2 + 3 + 4)
  assert(prod2 == 1 * 2 * 3 * 4)
  
  def isPerfect(n: Int): Boolean = {
    def sumDivisors(divisor: Int, sum: Int): Int = {
      if (divisor <= 0) sum
      else if (n % divisor == 0) sumDivisors(divisor - 1, sum + divisor)
      else sumDivisors(divisor - 1, sum)
    }
  
    val divSum = sumDivisors(n - 1, 0)
    divSum == n
  }
  
  // Testy
  assert(isPerfect(6))
  assert(isPerfect(8128))
  assert(!isPerfect(7))
  
  
  
  def insert(lista: List[Int], element: Int, pozycja: Int): List[Int] = {
    if (pozycja <= 0) {
      element :: lista
    } else {
      if (lista == Nil) {
        List(element)
      } else {
        val head = lista.head
        val tail = lista.tail
        head :: insert(tail, element, pozycja - 1)
      }
    }
  }
  
  val myList = List[Int](1, 2, 3, 4, 5)
  val newE = 99
  val pos = 2
  val nowaLista = insert(myList, newE, pos)
  
  def select(list : List[List[Int]] , indexList : List[Int] , result : List[Int] = Nil) : List[Int] = {
    def selectElement(sublist : List[Int] , index : Int) : OPtion[@@Int = {
      
      if(index < 0 ) {
      None
      } else if(sublist == Nil){
        List()
      } else {
        val head = sublist.head
        val tail = sublist.tail
        selectElement(tail,index - 1)
  
      }
    }
    val ihead = indexList.head
    val sublist = list.head
  
  
  
  
  
  }
  
  
}
```



#### Error stacktrace:

```
dotty.tools.dotc.core.SymDenotations$NoDenotation$.owner(SymDenotations.scala:2582)
	scala.meta.internal.pc.SignatureHelpProvider$.isValid(SignatureHelpProvider.scala:83)
	scala.meta.internal.pc.SignatureHelpProvider$.notCurrentApply(SignatureHelpProvider.scala:94)
	scala.meta.internal.pc.SignatureHelpProvider$.$anonfun$1(SignatureHelpProvider.scala:48)
	scala.collection.StrictOptimizedLinearSeqOps.loop$3(LinearSeq.scala:280)
	scala.collection.StrictOptimizedLinearSeqOps.dropWhile(LinearSeq.scala:282)
	scala.collection.StrictOptimizedLinearSeqOps.dropWhile$(LinearSeq.scala:278)
	scala.collection.immutable.List.dropWhile(List.scala:79)
	scala.meta.internal.pc.SignatureHelpProvider$.signatureHelp(SignatureHelpProvider.scala:48)
	scala.meta.internal.pc.ScalaPresentationCompiler.signatureHelp$$anonfun$1(ScalaPresentationCompiler.scala:375)
```
#### Short summary: 

java.lang.AssertionError: NoDenotation.owner